<!DOCTYPE html>
<html lang ="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width-device-width, initial-sacle=1.0">
<title>Documento</title>

<body>
<a href="P1_AP1.php">P1_AI1. Variables</a><br>
<a href="P1_AI2.php">P1_AI2. Comparaciones</a><br>
<a href="P1_AI3.php">P1_AI3. Calcular edad</a><br>
<a href="P1_AI4.php">P1_AP4. Ciclos</a><br>
<a href="P1_AI5.php">P1_AI5. Ejercicios</a><br>
<a href="P1_AI6.php">P1_AI6. x</a><br>
<a href="P1_AI7.php">P1_AI7. y</a><br>
<a href="P1_AI8.php">P1_AI8. y</a><br>
<a href="P1_AI9.php">P1_AI9. BD</a><br>
<a href="P1_AI10.php">P1_AI10. Estructura y HTTP</a><br>
</body>

</head>

