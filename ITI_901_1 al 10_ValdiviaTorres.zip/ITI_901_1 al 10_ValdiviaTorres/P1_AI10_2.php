
<?php include('layout/header.php');?>

<a href="P1_AI10.php">Regresar a Pagina 1</a>
<br><br>

<h1>Pagina 2</h1>

<?php include('layout/footer.php');?>
