<?php

function titulo($titulo)
{
    echo "<br><strong>$titulo</strong><br>";
}