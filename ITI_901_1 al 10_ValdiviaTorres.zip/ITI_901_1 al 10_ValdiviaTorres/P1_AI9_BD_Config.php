<?php
class BDConfig{
    public static $DBSERVER = 'localhost';
    public static $DBNAME ='daw901_p1_9';
    public static $DBUSER = 'root';
    public static $DBPASSWORD ='';
}


?>